

export const metadata = {
    title: 'Registration',
    description: 'Registration',
}
const LoginLayout = ({ children }) => {
    return children
};

export default LoginLayout;