export const metadata = {
    title: 'Login',
    description: 'Login to your account',
}

const LoginLayout = ({ children }) => {
    return children
};

export default LoginLayout;