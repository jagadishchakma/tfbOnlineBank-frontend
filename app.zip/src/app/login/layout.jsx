const LoginLayout = ({ children }) => {
    return children
};

export default LoginLayout;