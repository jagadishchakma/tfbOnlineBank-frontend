const DashboardLayout = () => {
    return (
        <nav>
            <ul>
                <li>dash1</li>
                <li>dash1</li>
                <li>dash1</li>
            </ul>
        </nav>
    );
};

export default DashboardLayout;