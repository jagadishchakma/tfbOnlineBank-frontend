export const metadata = {
    title: "TFB Dashboard",
    description: "TFB online banking is banking platform service for valuable customer.",
  };
const Dashboard = () => {
    return (
        <div>
            <h1>Dashboard</h1>
        </div>
    );
};

export default Dashboard;