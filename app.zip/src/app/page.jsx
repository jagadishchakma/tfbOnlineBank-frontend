
export const metadata = {
  title: "TFB Online Banking",
  description: "TFB online banking is banking platform service for valuable customer.",
};
const Home = () => {
  return (
    <div>
      <h1>Home Page</h1>
    </div>
  );
};

export default Home;
